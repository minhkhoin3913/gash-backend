const express = require('express');
const router = express.Router();
const ImportBillDetails = require('../models/ImportBillDetails');

// Create
router.post('/', async (req, res) => {
  try {
    const importBillDetail = new ImportBillDetails(req.body);
    await importBillDetail.save();
    res.status(201).json(importBillDetail);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Read all
router.get('/', async (req, res) => {
  try {
    const importBillDetails = await ImportBillDetails.find().populate('variant_id bill_id');
    res.json(importBillDetails);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Read one
router.get('/:id', async (req, res) => {
  try {
    const importBillDetail = await ImportBillDetails.findById(req.params.id);
    if (!importBillDetail) return res.status(404).json({ error: 'ImportBillDetail not found' });
    res.json(importBillDetail);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update
router.put('/:id', async (req, res) => {
  try {
    const importBillDetail = await ImportBillDetails.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    if (!importBillDetail) return res.status(404).json({ error: 'ImportBillDetail not found' });
    res.json(importBillDetail);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Delete
router.delete('/:id', async (req, res) => {
  try {
    const importBillDetail = await ImportBillDetails.findByIdAndDelete(req.params.id);
    if (!importBillDetail) return res.status(404).json({ error: 'ImportBillDetail not found' });
    res.json({ message: 'ImportBillDetail deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;