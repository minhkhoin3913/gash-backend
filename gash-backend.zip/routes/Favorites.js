const express = require('express');
const router = express.Router();
const Favorites = require('../models/Favorites');
const { authMiddleware, roleMiddleware } = require('../middleware/auth');

// Create (Authenticated users only)
router.post('/', authMiddleware, async (req, res) => {
  try {
    const favorite = new Favorites({ ...req.body, user_id: req.user.id });
    await favorite.save();
    const populatedFavorite = await Favorites.findById(favorite._id)
      .populate('user_id', 'username name')
      .populate('product_id', 'pro_name imageURL pro_price');
    res.status(201).json(populatedFavorite);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Read all (Authenticated users see their own favorites, admins/managers see all)
router.get('/', authMiddleware, async (req, res) => {
  try {
    let favorites;
    if (['admin', 'manager'].includes(req.user.role)) {
      favorites = await Favorites.find()
        .populate('user_id', 'username name')
        .populate('product_id', 'pro_name imageURL pro_price');
    } else {
      favorites = await Favorites.find({ user_id: req.user.id })
        .populate('user_id', 'username name')
        .populate('product_id', 'pro_name imageURL pro_price');
    }
    res.json(favorites);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Read one (Authenticated users can see their own favorites, admins/managers see all)
router.get('/:id', authMiddleware, async (req, res) => {
  try {
    const favorite = await Favorites.findById(req.params.id)
      .populate('user_id', 'username name')
      .populate('product_id', 'pro_name imageURL pro_price');
    if (!favorite) return res.status(404).json({ error: 'Favorite not found' });

    if (favorite.user_id.toString() !== req.user.id && !['admin', 'manager'].includes(req.user.role)) {
      return res.status(403).json({ error: 'Access denied' });
    }

    res.json(favorite);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete (Authenticated users can delete their own favorites, admins/managers can delete all)
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    const favorite = await Favorites.findById(req.params.id);
    if (!favorite) return res.status(404).json({ error: 'Favorite not found' });

    if (favorite.user_id.toString() !== req.user.id && !['admin', 'manager'].includes(req.user.role)) {
      return res.status(403).json({ error: 'Access denied' });
    }

    await Favorites.findByIdAndDelete(req.params.id);
    res.json({ message: 'Favorite deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;