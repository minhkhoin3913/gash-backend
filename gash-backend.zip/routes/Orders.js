const express = require('express');
const router = express.Router();
const Orders = require('../models/Orders');
const { authMiddleware, roleMiddleware } = require('../middleware/auth');

// Create (Authenticated users only)
router.post('/', authMiddleware, async (req, res) => {
  try {
    const order = new Orders({ ...req.body, user_id: req.user.id });
    await order.save();
    const populatedOrder = await Orders.findById(order._id)
      .populate('user_id', 'username name')
      .populate('items.product_id', 'pro_name imageURL pro_price');
    res.status(201).json(populatedOrder);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Read all (Authenticated users see their own orders, admins/managers see all)
router.get('/', authMiddleware, async (req, res) => {
  try {
    let orders;
    if (['admin', 'manager'].includes(req.user.role)) {
      orders = await Orders.find()
        .populate('user_id', 'username name')
        .populate('items.product_id', 'pro_name imageURL pro_price');
    } else {
      orders = await Orders.find({ user_id: req.user.id })
        .populate('user_id', 'username name')
        .populate('items.product_id', 'pro_name imageURL pro_price');
    }
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Read one (Authenticated users can see their own orders, admins/managers see all)
router.get('/:id', authMiddleware, async (req, res) => {
  try {
    const order = await Orders.findById(req.params.id)
      .populate('user_id', 'username name')
      .populate('items.product_id', 'pro_name imageURL pro_price');
    if (!order) return res.status(404).json({ error: 'Order not found' });

    if (order.user_id.toString() !== req.user.id && !['admin', 'manager'].includes(req.user.role)) {
      return res.status(403).json({ error: 'Access denied' });
    }

    res.json(order);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update (Admin/Manager only)
router.put('/:id', authMiddleware, roleMiddleware(['admin', 'manager']), async (req, res) => {
  try {
    const order = await Orders.findByIdAndUpdate(req.params.id, req.body, { new: true })
      .populate('user_id', 'username name')
      .populate('items.product_id', 'pro_name imageURL pro_price');
    if (!order) return res.status(404).json({ error: 'Order not found' });
    res.json(order);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Delete (Admin/Manager only)
router.delete('/:id', authMiddleware, roleMiddleware(['admin', 'manager']), async (req, res) => {
  try {
    const order = await Orders.findByIdAndDelete(req.params.id);
    if (!order) return res.status(404).json({ error: 'Order not found' });
    res.json({ message: 'Order deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;