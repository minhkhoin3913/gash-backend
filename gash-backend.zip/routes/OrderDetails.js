const express = require('express');
const router = express.Router();
const OrderDetails = require('../models/OrderDetails');

// Create
router.post('/', async (req, res) => {
  try {
    const orderDetail = new OrderDetails(req.body);
    await orderDetail.save();
    res.status(201).json(orderDetail);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Read all
router.get('/', async (req, res) => {
  try {
    const orderDetails = await OrderDetails.find().populate('variant_id order_id');
    res.json(orderDetails);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Read one
router.get('/:id', async (req, res) => {
  try {
    const orderDetail = await OrderDetails.findById(req.params.id);
    if (!orderDetail) return res.status(404).json({ error: 'OrderDetail not found' });
    res.json(orderDetail);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update
router.put('/:id', async (req, res) => {
  try {
    const orderDetail = await OrderDetails.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    if (!orderDetail) return res.status(404).json({ error: 'OrderDetail not found' });
    res.json(orderDetail);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Delete
router.delete('/:id', async (req, res) => {
  try {
    const orderDetail = await OrderDetails.findByIdAndDelete(req.params.id);
    if (!orderDetail) return res.status(404).json({ error: 'OrderDetail not found' });
    res.json({ message: 'OrderDetail deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;