const express = require('express');
const router = express.Router();
const ProductImages = require('../models/ProductImages');

// Create
router.post('/', async (req, res) => {
  try {
    const productImage = new ProductImages(req.body);
    await productImage.save();
    res.status(201).json(productImage);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Read all
router.get('/', async (req, res) => {
  try {
    const productImages = await ProductImages.find().populate('product_id');
    res.json(productImages);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Read one
router.get('/:id', async (req, res) => {
  try {
    const productImage = await ProductImages.findById(req.params.id);
    if (!productImage) return res.status(404).json({ error: 'ProductImage not found' });
    res.json(productImage);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update
router.put('/:id', async (req, res) => {
  try {
    const productImage = await ProductImages.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    if (!productImage) return res.status(404).json({ error: 'ProductImage not found' });
    res.json(productImage);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Delete
router.delete('/:id', async (req, res) => {
  try {
    const productImage = await ProductImages.findByIdAndDelete(req.params.id);
    if (!productImage) return res.status(404).json({ error: 'ProductImage not found' });
    res.json({ message: 'ProductImage deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;