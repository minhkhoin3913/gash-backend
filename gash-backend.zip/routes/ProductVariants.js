const express = require('express');
const router = express.Router();
const ProductVariants = require('../models/ProductVariants');

// Create
router.post('/', async (req, res) => {
  try {
    const productVariant = new ProductVariants(req.body);
    await productVariant.save();
    res.status(201).json(productVariant);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Read all
router.get('/', async (req, res) => {
  try {
    const productVariants = await ProductVariants.find().populate('product_id color_id image_id');
    res.json(productVariants);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Read one
router.get('/:id', async (req, res) => {
  try {
    const productVariant = await ProductVariants.findById(req.params.id);
    if (!productVariant) return res.status(404).json({ error: 'ProductVariant not found' });
    res.json(productVariant);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update
router.put('/:id', async (req, res) => {
  try {
    const productVariant = await ProductVariants.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    if (!productVariant) return res.status(404).json({ error: 'ProductVariant not found' });
    res.json(productVariant);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Delete
router.delete('/:id', async (req, res) => {
  try {
    const productVariant = await ProductVariants.findByIdAndDelete(req.params.id);
    if (!productVariant) return res.status(404).json({ error: 'ProductVariant not found' });
    res.json({ message: 'ProductVariant deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;