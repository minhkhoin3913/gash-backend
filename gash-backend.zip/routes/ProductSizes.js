const express = require('express');
const router = express.Router();
const ProductSizes = require('../models/ProductSizes');

// Create
router.post('/', async (req, res) => {
  try {
    const productSize = new ProductSizes(req.body);
    await productSize.save();
    res.status(201).json(productSize);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Read all
router.get('/', async (req, res) => {
  try {
    const productSizes = await ProductSizes.find();
    res.json(productSizes);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Read one
router.get('/:id', async (req, res) => {
  try {
    const productSize = await ProductSizes.findById(req.params.id);
    if (!productSize) return res.status(404).json({ error: 'ProductSize not found' });
    res.json(productSize);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update
router.put('/:id', async (req, res) => {
  try {
    const productSize = await ProductSizes.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    if (!productSize) return res.status(404).json({ error: 'ProductSize not found' });
    res.json(productSize);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Delete
router.delete('/:id', async (req, res) => {
  try {
    const productSize = await ProductSizes.findByIdAndDelete(req.params.id);
    if (!productSize) return res.status(404).json({ error: 'ProductSize not found' });
    res.json({ message: 'ProductSize deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;