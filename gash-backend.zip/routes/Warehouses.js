const express = require('express');
const router = express.Router();
const Warehouses = require('../models/Warehouses');
const { authMiddleware, roleMiddleware } = require('../middleware/auth');

// Create (Admin/Manager only)
router.post('/', authMiddleware, roleMiddleware(['admin', 'manager']), async (req, res) => {
  try {
    const { variant_id, bill_id, import_date, inventory_number } = req.body;
    const warehouse = new Warehouses({
      variant_id,
      bill_id,
      import_date: import_date || new Date(),
      inventory_number,
    });
    await warehouse.save();
    const populatedWarehouse = await Warehouses.findById(warehouse._id)
      .populate('variant_id', 'pro_id color_id size_id')
      .populate('bill_id', 'create_date total_amount');
    res.status(201).json(populatedWarehouse);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Read all (Admin/Manager only)
router.get('/', authMiddleware, roleMiddleware(['admin', 'manager']), async (req, res) => {
  try {
    const warehouses = await Warehouses.find()
      .populate('variant_id', 'pro_id color_id size_id')
      .populate('bill_id', 'create_date total_amount');
    res.json(warehouses);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Read one (Admin/Manager only)
router.get('/:id', authMiddleware, roleMiddleware(['admin', 'manager']), async (req, res) => {
  try {
    const warehouse = await Warehouses.findById(req.params.id)
      .populate('variant_id', 'pro_id color_id size_id')
      .populate('bill_id', 'create_date total_amount');
    if (!warehouse) return res.status(404).json({ error: 'Warehouse record not found' });
    res.json(warehouse);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update (Admin/Manager only)
router.put('/:id', authMiddleware, roleMiddleware(['admin', 'manager']), async (req, res) => {
  try {
    const { variant_id, bill_id, import_date, inventory_number } = req.body;
    const updates = { variant_id, bill_id, import_date, inventory_number };
    const warehouse = await Warehouses.findByIdAndUpdate(req.params.id, updates, { new: true })
      .populate('variant_id', 'pro_id color_id size_id')
      .populate('bill_id', 'create_date total_amount');
    if (!warehouse) return res.status(404).json({ error: 'Warehouse record not found' });
    res.json(warehouse);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Delete (Admin/Manager only)
router.delete('/:id', authMiddleware, roleMiddleware(['admin', 'manager']), async (req, res) => {
  try {
    const warehouse = await Warehouses.findByIdAndDelete(req.params.id);
    if (!warehouse) return res.status(404).json({ error: 'Warehouse record not found' });
    res.json({ message: 'Warehouse record deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;