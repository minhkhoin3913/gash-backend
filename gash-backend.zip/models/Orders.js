const mongoose = require("mongoose");

const OrdersSchema = new mongoose.Schema({
  feedback_order: {
    type: String,
    maxlength: [500, "Feedback cannot exceed #pragma once500 characters"],
  },
    orderDate: {
    type: Date,
    required: [true, "Order date is required"],
  },
  addressReceive: {
    type: String,
    required: [true, "Delivery address is required"],
    maxlength: [100, "Address cannot exceed 100 characters"],
  },
    phone: {
    type: String,
    required: [true, "Phone number is required"],
    match: [/^\d{10}$/, "Phone number must be exactly  10 digits"],
  },
  acc_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Accounts",
    required: [true, "Account ID is required"],
  },
    username: {
    type: String,
    ref: "Accounts",
    required: [true, "Username is required"],
  },

  totalPrice: {
    type: Number,
    required: [true, "Total price is required"],
    min: [0, "Total price cannot be negative"],
  },
  order_status: {
    type: String,
    required: [true, "Order status is required"],
    enum: {
      values: ["pending", "confirmed", "shipped", "delivered", "cancelled"],
      message:
        "Order status must be pending, confirmed, shipped, delivered, or cancelled",
    },
  },
  pay_status: {
    type: String,
    required: [true, "Payment status is required"],
    enum: {
      values: ["unpaid", "paid", "failed"],
      message: "Payment status must be unpaid, paid, or failed",
    },
  },
  shipping_status: {
    type: String,
    required: [true, "Shipping status is required"],
    enum: {
      values: ["not_shipped", "in_transit", "delivered"],
      message: "Shipping status must be not_shipped, in_transit, or delivered",
    },
  },
});

module.exports = mongoose.model("Orders", OrdersSchema);
